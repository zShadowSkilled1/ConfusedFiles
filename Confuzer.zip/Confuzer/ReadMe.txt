bro why is this so cursed

folder name is spaces and there are two folder with same names
also if u open the second OpenMe folder then click the image it will be diffrent

wtf bro there is also a folder named "CON"